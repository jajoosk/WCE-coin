<?php
ob_start();
session_start();
 
$name = $_SESSION['name'];
$balance = $_SESSION['balance'];

?>

<html>
<style>
.navbar {
    overflow: hidden;
    background-color: #333;
    position: fixed; /* Set the navbar to fixed position */
    top: 0; /* Position the navbar at the top of the page */
    width: 100%; /* Full width */
}

/* Links inside the navbar */
.navbar a {
    float: right;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 25%;
}
form {
    border: 40px solid #f1f1f1;
}
</style>

<body>

<div class="navbar">
  <a href="index.html">Home</a>
  <a href=""><?php echo htmlentities($name);?></a>
  <a href=""><?php echo htmlentities($balance);?></a>

  <a href="logout.php">logout</a> 
</div>

<div id="contact-form">

  <form  method="post" action="key.php">
		<div align=center >
			<h1 >Request coin</h1>
		      <label for="to">
		      	<span class="required" >To*:</span>
		      	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" id="to" name="request" placeholder="Enter wallet address " required="required" tabindex="1" autofocus="autofocus" />

		      	
		      	 </label>  
			</div>
			
			<div  align=center >		          
		      <label for="amount"   >
		      	<span class="required"   >Amount*:</span> 
		      	<input type="text"   id="amount" name="amount" placeholder="Enter amount " required="required" tabindex="1" autofocus="autofocus" />
		      				     

		      </label> 
			</div>
			
<div  align=center class="wrapper">
<button name="request" type="submit" id="submit" align="center"> Request</button> 

</div>

</form>
</div>

</body>
</html>
