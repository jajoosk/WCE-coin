<?php 

ob_start();
session_start();
require_once 'dbconnect.php';

/*function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}*/



$email=$_SESSION['email'];
$myw=$_SESSION['wallet'];
$mail = preg_replace("/[^a-z0-9]/", "", $email);

		//verify by others code
		//$res4=mysql_query("SELECT * FROM ".$mail);
		$res4=mysql_query("SELECT * FROM ".$mail." order by id desc limit 1");
		$row4=mysql_fetch_array($res4);
		$nonce=$row4['nonce'];
		
		$walletaddencrypted=$row4['recipient'];
		$amountencrypted=$row4['amount'];
		$pubkey=$row4['pubkey'];
		$n=$row4['n'];
		$senderadd=$row4['sender'];

		$difficulty=$row4['difficulty'];
				
		exec('python decryption.py '.$walletaddencrypted.' '.$pubkey.' '.$n.'',$output,$ret_code);
		exec('python decryption.py '.$amountencrypted.' '.$pubkey.' '.$n.'',$output1,$ret_code);
	//echo "amount decrypted ".$output1[0];
	
		$receiver=$output[0];
		$amountbalance=$output1[0];
	
		$transaction=$output[0]."".$output1[0];
		
		$res1=mysql_query("SELECT * FROM Blockchain order by id desc limit 1");
	
		$row1=mysql_fetch_array($res1);
	
	//echo $row['blockhash'];
	
		$prevblockhash=$row1['blockhash'];
		
		//$res4=mysql_query("SELECT * FROM ".$mail);
		$res4=mysql_query("SELECT * FROM ".$mail." order by id desc limit 1");
		$row4=mysql_fetch_array($res4);
		
		
		exec('python verificationofblock.py '.$transaction.' '.$difficulty.' '.$prevblockhash.' '.$nonce.'',$output3,$ret_code);
		//echo $output3[0];
		if($output3[0]=="1")
		{
		
			//$res5=mysql_query("SELECT flag FROM ".$mail);
			$res5=mysql_query("SELECT * FROM ".$mail." order by id desc limit 1");
			$row5=mysql_fetch_array($res5);
			$flag=$row5['flag'];
			$flag=$flag+1;
			
			$res6=mysql_query("SELECT * FROM BitcoinProject WHERE login=1");

		

			while($row6 = mysql_fetch_array($res6))
			{
				$resultset[]=$row6;
			}
			foreach($resultset as $result)
			{
				$email=$result[1];
				$mail = preg_replace("/[^a-z0-9]/", "", $email);
			
				$query = "update ".$mail." set flag='$flag'";
				$res = mysql_query($query);
			}
			echo "flag set";
			
		}
			
		else
		{
			echo "verification failed   ";
		}
		echo "I am verifier";
		
	/*$host = getRealIpAddr();
	$host=10.10.13.145;
	echo $host;
	$port = 80;
	$socket = socket_create(AF_INET, SOCK_STREAM, 0) or die("Could not create socket\n");
	$result = socket_connect($socket, $host, $port) or die("Could not connect toserver\n");
	$message = "checked";
	socket_write($socket, $message, strlen($message)) or die("Could not send data to server\n");*/
	
?>
