import hashlib as hasher
import sys
def hash_block(transaction,prevhash,nonce):
    trans=str(transaction)+str(prevhash)+str(nonce)
    sha = hasher.sha256(trans)
    return sha.hexdigest()
    
if __name__ == '__main__':
	
	transaction=sys.argv[1]
	difficulty=sys.argv[2]
	prevhash=sys.argv[3]
	nonce=0
	prevhash = prevhash
	finalhash = hash_block(transaction,prevhash,nonce)

	while(finalhash < difficulty):
		finalhash = hash_block(transaction,prevhash,nonce)
		nonce += 1;
		
	print finalhash
	print nonce
	
