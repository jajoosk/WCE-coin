
<?php

ob_start();
session_start();
$private="";
$public="";
$wallet="";

$name = $_SESSION['name'];
$balance=$_SESSION['balance'];
include_once 'dbconnect.php';


if(isset($_POST['generate']))
{
	exec('python generatekey.py',$output,$ret_code);

	
	$private=$output[0];
	$public=$output[1];
	$n=$output[2];
	$wallet=$output[3];
	$query = "UPDATE BitcoinProject SET prkey=$private, pubkey=$public, walletadd='$wallet',n=$n WHERE name='$name'";
  	$res = mysql_query($query);
 	
	
}
if(isset($_POST['ok']))
{
	
	$res1=mysql_query("SELECT * FROM BitcoinProject WHERE name='$name'");
   	$row=mysql_fetch_array($res1);
   	$_SESSION["wa"]=$row['walletadd'];
	header("Location: sample.php");

}
?>

<html>
<style>

.wrapper {
    text-align: center;
}


form {
    border: 20px solid #f1f1f1;
}

input[type=text], input[type=password] {
    width: 25%;
    padding: 12px 20px;
    margin: 8px ;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 25%;
}

button:hover {
    opacity: 0.8;
}

.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}

.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
}

img.avatar {
    width: 20%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

.logoutLblPos{

   position:fixed;
   right:10px;
   top:5px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 25%;
    }
}
.navbar {
    overflow: hidden;
    background-color: #333;
    position: fixed; /* Set the navbar to fixed position */
    top: 0; /* Position the navbar at the top of the page */
    width: 100%; /* Full width */
}

/* Links inside the navbar */
.navbar a {
    float: right;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}
</style>
<body>



<!-- 
  ****************************************
  Contest Entry for Treehouse:
  "Design a Contact Form"
  Submitted by Lisa Wagner
  ****************************************
-->


<!--div class="navbar">
  <a href="index.html">Home</a>
  <a href=""><?php echo htmlentities($name);?></a>
    <a href=""><?php echo htmlentities($balance);?></a>

  <a href="logout.php">logout</a> 
</div-->

<div id="contact-form">

  <form method="post" action="key.php">
		<div>
			<h1>Key Generation</h1>
		      <label for="email">
		      	<span class="required">Private Key: </span>
		      	<input type="password" readonly=true id="name" name="privatekey" value="<?php echo htmlentities($private);?>" placeholder=" " required="required" tabindex="1" autofocus="autofocus" />

		      	<button name="generate" type="submit" id="submit" >Generate Private Key</button> 
		
		      			      </label>  
			</div>
			<div>		          
		      <label for="name">
		      	<span class="required">Public Key: </span> 
		      	<input type="text" readonly=true id="name" name="publickey" value="<?php echo htmlentities($public);?>" placeholder=" " required="required" tabindex="1" autofocus="autofocus" />
		      				     

		      </label> 
			</div>
			
<div>

<label for="subject">
		      <span>Wallet Address: </span>
		      <input type="text" readonly=true id="name" name="wallet" value="<?php echo htmlentities($wallet);?>" placeholder=" " required="required" tabindex="1" autofocus="autofocus" />
			      </label>
			</div>
<div class="wrapper">
<button name="ok" type="submit" id="submit" align="center"> OK</button> 

</div>

</form>

<!--form align="right" name="form1" method="post" action="logout.php">
  <label class="logoutLblPos">
 <label for = "name"><?php echo htmlentities($name);?><br />
  <input name="logout" type="submit" id="submit2" value="log out">
  </label>
</form-->
</div>
</body>
</html>

