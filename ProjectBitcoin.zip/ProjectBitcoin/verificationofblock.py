import hashlib as hasher
import sys
def hash_block(transaction,prevhash,nonce):
    trans=str(transaction)+str(prevhash)+str(nonce)
    sha = hasher.sha256(trans)
    return sha.hexdigest()
    
if __name__ == '__main__':
	
	transaction=sys.argv[1]
	difficulty=sys.argv[2]
	prevhash=sys.argv[3]
	nonce=sys.argv[4]
	prevhash = prevhash
	finalhash = hash_block(transaction,prevhash,nonce)
	if(finalhash < difficulty):
		print("1")
	else:
		print("0")
		
