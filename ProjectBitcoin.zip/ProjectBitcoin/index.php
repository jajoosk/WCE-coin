<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
if(isset($_SESSION['name'])){
header("Location: sample.php");
exit;
}
else
{
	header("Location: login.php");
}
?>
