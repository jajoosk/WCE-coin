<?php
  session_start();
  
  
$name = $_SESSION['name'];
include_once 'dbconnect.php';
$query = "UPDATE BitcoinProject SET login=0 WHERE name='$name'";
$res = mysql_query($query);
  session_destroy();
  session_unset();
  //echo "Hello";
  header("Location:index.html");
  exit;
 ?>
