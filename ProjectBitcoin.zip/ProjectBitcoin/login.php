<?php
 ob_start();
 session_start();
 header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");

 require_once 'dbconnect.php';

    if(isset($_SESSION['name'])) 
    { 
        header('Location: index.php'); 

    }
    
    else{
 $error = false;
 
 if( isset($_POST['btn-login']) ) { 
  
  // prevent sql injections/ clear user invalid inputs
  $email = trim($_POST['email']);
  $email = strip_tags($email);
  $email = htmlspecialchars($email);
  
  $pass = trim($_POST['pass']);
  $pass = strip_tags($pass);
  $pass = htmlspecialchars($pass);
  // prevent sql injections / clear user invalid inputs
  echo "error";
  if(empty($email)){
   $error = true;
   $emailError = "Please enter your email address.";
  } else if ( !filter_var($email,FILTER_VALIDATE_EMAIL) ) {
   $error = true;
   $emailError = "Please enter valid email address.";
  }
  
  if(empty($pass)){
   $error = true;
   $passError = "Please enter your password.";
  }
  
  // if there's no error, continue to login
  if (!$error) {
   
   $password = hash('sha256', $pass); // password hashing using SHA256
  
   $res=mysql_query("SELECT * FROM BitcoinProject WHERE email='$email'");
   $row=mysql_fetch_array($res);
   $count = mysql_num_rows($res); // if uname/pass correct it returns must be 1 row
   $_SESSION['balance']=$row['balance'];
  
   $mail = preg_replace("/[^a-z0-9]/", "", $email);
   $_SESSION['email']=$mail;

   
   if( $count == 1 && $row['password']==$password && empty($row['pubkey'])) {
	$_SESSION["name"] = $row['name'];

	$query = "UPDATE BitcoinProject SET login=1 WHERE email='$email'";
  	$res = mysql_query($query);
  	

    header("Location: key.php");
   }
   else if(!empty($row['pubkey']))
   {
   	$_SESSION["name"] = $row['name'];
   	$query = "UPDATE BitcoinProject SET login=1 WHERE email='$email'";
  	$res = mysql_query($query);
   	$_SESSION["wa"]=$row['walletadd'];
   	header("Location: sample.php");	
   } 
   else
    {
    $errMSG = "Incorrect Credentials, Try again...";
    $_SESSION['errmsg']=$errMSG;
    echo $errMSG;
    //header("Location: login.php");
   }
    
  }
  
 }
 }

 ?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>

<div id="errmsg">
<?php if(!empty($_SESSION['errmsg'])) {echo $_SESSION['errmsg']; $_SESSION['errmsg']="";}?>
</div>

<div class="container">

 <div id="login-form">
    <form method="post" action="login.php" autocomplete="off">
    
     <div class="col-md-12">
        
         <div class="form-group">
             <h2 class="">Sign In.</h2>
            </div>
        
        
         <div class="form-group">
             <hr />
            </div>
            
          
          


  
 
            
            <div class="form-group">
             <div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
             <input type="email" name="email" class="form-control" placeholder="Your Email" maxlength="40" />
                </div>
                <span class="text-danger"><?php echo $emailError; ?></span>
            </div>
            
            <div class="form-group">
             <div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
             <input type="password" name="pass" class="form-control" placeholder="Your Password" maxlength="15" />
                </div>
                <span class="text-danger"><?php echo $passError; ?></span>
            </div>
            
            <div class="form-group">
             <hr />
            </div>
            
            <div class="form-group">
            
          

             <button type="submit" class="btn btn-block btn-primary" name="btn-login" >Sign In</button>
             </form>
            </div>
            
            <div class="form-group">
             <hr />
            </div>
            
            
        
        </div>
   
    </form>
    </div> 

</div>



</body>
</html>


