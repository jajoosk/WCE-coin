<?php 

ob_start();
session_start();
require_once 'dbconnect.php';

$email=$_SESSION['email'];
$myw=$_SESSION['wa'];

$mail = preg_replace("/[^a-z0-9]/", "", $email);
$res=mysql_query("SELECT * FROM ".$mail." order by id desc limit 1");
$row=mysql_fetch_array($res);
$count = mysql_num_rows($res);

$winamt=3;

if($count==1)
{

	$walletaddencrypted=$row['recipient'];
	$amountencrypted=$row['amount'];
	$pubkey=$row['pubkey'];
	$n=$row['n'];
	$senderadd=$row['sender'];
	$nonce=$row['nonce'];
	$difficulty=$row['difficulty'];
	exec('python decryption.py '.$walletaddencrypted.' '.$pubkey.' '.$n.'',$output,$ret_code);
	exec('python decryption.py '.$amountencrypted.' '.$pubkey.' '.$n.'',$output1,$ret_code);
	//echo "amount decrypted ".$output1[0];
	
	$receiver=$output[0];
	$amountbalance=$output1[0];
	
	$transaction=$output[0]."".$output1[0];
	
	$res1=mysql_query("SELECT * FROM Blockchain order by id desc limit 1");
	
	$row1=mysql_fetch_array($res1);
	
	//echo $row['blockhash'];
	
	$prevblockhash=$row1['blockhash'];
	//echo $transaction."\n".$difficulty."\n".$prevblockhash."\n";
	//print(exec('python createblock.py '.$transaction.' '.$difficulty.' '.$prevblockhash.'',$output2,$ret_code));
	exec('python createblock.py '.$transaction.' '.$difficulty.' '.$prevblockhash.'',$output2,$ret_code);
	
	
	$hash=$output2[0];
	$no=$output2[1];
	$res2=mysql_query("SELECT * FROM ".$mail." order by id desc limit 1");
	$row2=mysql_fetch_array($res2);
	$newnonce=$row2['nonce'];
	if($nonce==$row2['nonce'])
	{
		//echo $_SESSION['wallet']."\n";
		//echo $row2['sender']."\n";
		//echo $output[0]."\n";
		

		$query="SELECT * FROM BitcoinProject WHERE login=1";

		$res3=mysql_query($query);
		$nooflogin=mysql_num_rows($res3);
		$nooflogin=$nooflogin-3;
		/*if($res2)
		{
			echo "succes";
		}
		else
		{
			echo "fail";
		}
		
		*/
		while($row3 = mysql_fetch_array($res3))
		{
			$resultset[]=$row3;
		}
		foreach($resultset as $result)
		{
			$email=$result[1];
			$mail = preg_replace("/[^a-z0-9]/", "", $email);

			$query = "update ".$mail." set nonce='$no',winnerminer='$myw'";
			$res = mysql_query($query);
			
		}
		echo "I am miner";
		
		$res7=mysql_query("SELECT * FROM ".$mail." order by id desc limit 1");
		$row7=mysql_fetch_array($res7);
		while($row7['flag']==0)
		{
			//$res7=mysql_query("SELECT * FROM ".$mail);
			$res7=mysql_query("SELECT * FROM ".$mail." order by id desc limit 1");
			$row7=mysql_fetch_array($res7);	
		}
		while($row7['flag']!=$nooflogin)
		{
			//$res7=mysql_query("SELECT * FROM ".$mail);
			$res7=mysql_query("SELECT * FROM ".$mail." order by id desc limit 1");
			$row7=mysql_fetch_array($res7);	
		}
		if($row7['winnerminer']==$myw)
		{
			$res8=mysql_query("SELECT balance FROM BitcoinProject WHERE walletadd='$myw'"); 
			if ($res8) 
			{
				//echo 'res8';
			} 
			else 
			{
				echo 'failure';
			}
			$row8=mysql_fetch_array($res8);
			$balance=$row8['balance']+(int)$winamt;
			//$balance=(int)$balance+(int)$winamt;
			$res9=mysql_query("update BitcoinProject set balance='$balance' WHERE walletadd='$myw'");
			
			//echo $row7['winnerminer']; 
			
			if ($res9) 
			{
				echo 'res9';
			} 
			else 
			{
				echo 'failure';
			}		
			$res10=mysql_query("SELECT balance FROM BitcoinProject WHERE walletadd='$senderadd'");
			if ($res10) 
			{
			//	echo 'res10';
			} 
			else 
			{
				echo 'failure';
			} 
			$row10=mysql_fetch_array($res10);
			$balance=$row10['balance']-(int)$amountbalance;
			$res11=mysql_query("update BitcoinProject set balance='$balance' WHERE walletadd='$senderadd'"); 			
			if ($res11) 
			{
			//	echo 'res11';
			} 
			else 
			{
				echo 'failure';
			}		
				
			$res12=mysql_query("SELECT balance FROM BitcoinProject WHERE walletadd='$receiver'");
			if ($res12) 
			{
				//echo 'res12';
			} 
			else 
			{
				echo 'failure';
			} 
			$row12=mysql_fetch_array($res12);
			$balance=$row12['balance']+(int)$amountbalance;
			$res13=mysql_query("update BitcoinProject set balance='$balance' WHERE walletadd='$receiver'"); 			
			if ($res13) 
			{
				//echo 'res13';
			} 
			else 
			{
				echo 'failure';
			}
		
		
			$res14=mysql_query("insert into Blockchain(blockhash) values('$hash')");
			//echo "bhaitad sonal";
			if($res14)
			{
				echo "mining success";
				echo "I am winner";
			}
			else
			{
				echo mysql_error();
			}
			
		}
		exit;
			
	}
	else
	{
		exec('python verificationofblock.py '.$transaction.' '.$difficulty.' '.$prevblockhash.' '.$newnonce.'',$output3,$ret_code);
		//echo $output3[0];
		if($output3[0]=="1")
		{
		
			//$res5=mysql_query("SELECT flag FROM ".$mail);
			$res5=mysql_query("SELECT * FROM ".$mail." order by id desc limit 1");
			$row5=mysql_fetch_array($res5);
			$flag=$row5['flag'];
			$flag=$flag+1;
			
			$res6=mysql_query("SELECT * FROM BitcoinProject WHERE login=1");

		

			while($row6 = mysql_fetch_array($res6))
			{
				$resultset[]=$row6;
			}
			foreach($resultset as $result)
			{
				$email=$result[1];
				$mail = preg_replace("/[^a-z0-9]/", "", $email);
			
				$query = "update ".$mail." set flag='$flag'";
				$res = mysql_query($query);
			}
			echo "flag set";
			exit;
		}
		
	}
		
	
}
?>
