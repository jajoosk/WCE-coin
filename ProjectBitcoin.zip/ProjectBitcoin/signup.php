<?php
 ob_start();
 session_start();
 
 include_once 'dbconnect.php';

 $error = false;

 if ( isset($_POST['btn-signup']) ) {
  
  // clean user inputs to prevent sql injections
  $name = trim($_POST['name']);
  $name = strip_tags($name);
  $name = htmlspecialchars($name);
  
  $email = trim($_POST['email']);
  $email = strip_tags($email);
  $email = htmlspecialchars($email);
  
  $pass = trim($_POST['pass']);
  $pass = strip_tags($pass);
  $pass = htmlspecialchars($pass);
  
  $acc =$_POST['accountno'];
  
  if (empty($name)) {
        $error = true;
  	$accerr="Please enter your account no";
  }
  // basic name validation
  if (empty($name)) {
   $error = true;
   $nameError = "Please enter your full name.";
  } else if (strlen($name) < 3) {
   $error = true;
   $nameError = "Name must have atleat 3 characters.";
  } else if (!preg_match("/^[a-zA-Z ]+$/",$name)) {
   $error = true;
   $nameError = "Name must contain alphabets and space.";
  }
  
  //basic email validation
  if ( !filter_var($email,FILTER_VALIDATE_EMAIL) ) {
   $error = true;
   $emailError = "Please enter valid email address.";
  } else {
   // check email exist or not
   $query = "SELECT email FROM BitcoinProject WHERE email='$email'";
   $query1 = "SELECT accountno FROM BankAccount WHERE accountno='$acc'";
   $result = mysql_query($query);
   $result1 = mysql_query($query1);
   $count = mysql_num_rows($result);
   $count1 = mysql_num_rows($result1);
   if($count!=0){
    $error = true;
    $emailError = "Provided Email is already in use.";
   }
   else if($count1!=0){
    $error = true;
    $emailError = "Provided Account No. is already in use.";
   }
  }
  // password validation
  if (empty($pass)){
   $error = true;
   $passError = "Please enter password.";
  } /*else if(strlen($pass) < 6) {
   $error = true;
   $passError = "Password must have atleast 6 characters.";
  }*/
  
  // password encrypt using SHA256();
  $password = hash('sha256', $pass);
  
  // if there's no error, continue to signup
  if( !$error ) {
   
   $query = "INSERT INTO BitcoinProject(name,email,password,balance) VALUES('$name','$email','$password',10)";
   $res = mysql_query($query);
   $_SESSION['balance']='10';

   $bal=mt_rand(10,500);
   $query1 = "INSERT INTO BankAccount(email,accountno,balance) VALUES('$email',$acc,$bal)";
   $res1 = mysql_query($query1);
   mysql_select_db( 'Bitcoin' );
   $mail = preg_replace("/[^a-z0-9]/", "", $email);
   //$query2 = "CREATE TABLE ".$mail."(sender VARCHAR(256),recipient TEXT(5000),amount  VARCHAR(255),difficulty VARCHAR(256),pubkey INT(255),nonce INT(255),flag INT(255),n INT(255),winnerminer VARCHAR(256))";
   $query2 = "CREATE TABLE ".$mail."(id INT(255) NOT NULL AUTO_INCREMENT,sender VARCHAR(256),recipient TEXT(5000),amount  VARCHAR(255),difficulty VARCHAR(256),pubkey INT(255),nonce INT(255),flag INT(255),n INT(255),winnerminer VARCHAR(256),PRIMARY KEY (id))";
   $res2 = mysql_query($query2);
   
   $_SESSION['email']=$mail;

   if ($res2) 
   {
    $errTyp = "success";
    $errMSG = "Successfully registered, you may login now";
    unset($name);
    unset($email);
    unset($pass);
    echo $errMSG;
    
   } else {
    $errTyp = "danger";
    $errMSG = "Something went wrong, try again later...";
    echo $errMSG; 
   } 
    
  }
  header('Location: login.php');
	exit;
  
 }
?>

