<?php
ob_start();
session_start();
$balance = $_SESSION['balance'];

$name = $_SESSION['name'];

require_once 'dbconnect.php';
 if( isset($_POST['send']) ) {
 
   $walletadd =$_POST['to'];
   
   $res=mysql_query("SELECT name FROM BitcoinProject WHERE walletadd='$walletadd'");
   $row=mysql_fetch_array($res);
   $count = mysql_num_rows($res); // if uname/pass correct it returns must be 1 row
   
   if( $count == 1)
   {
     	   $res1=mysql_query("SELECT * FROM BitcoinProject WHERE name='$name'");
	   $row1=mysql_fetch_assoc($res1);
	   $bal =$_POST['amount'];

	   $privatekey=$row1['prkey'];
	   $n=$row1['n'];
	   if( $bal <= $row1['balance'] ){
	   	//echo "success";

		exec('python encryption.py '.$walletadd.' '.$privatekey.' '.$n.'',$output,$ret_code);
		
		
		
		//echo "".$output[0]."\n";
		exec('python encryption.py '.$bal.' '.$privatekey.' '.$n.'',$output1,$ret_code);
		
		
		$walletaddmy=$row1['walletadd'];
		$publickeymy=$row1['pubkey'];
		mysql_select_db( 'Bitcoin' );
		
		$qur = "SELECT * FROM BitcoinProject WHERE login=1";

		$res2=mysql_query($qur);
		
		
		
		while($row2 = mysql_fetch_array($res2))
		{
			$resultset[]=$row2;
		}
		foreach($resultset as $result)
		{
			$email=$result[1];
			$mail = preg_replace("/[^a-z0-9]/", "", $email);
			
			$query = "INSERT INTO ".$mail."(sender, recipient, amount, difficulty, pubkey, nonce, flag, n) VALUES('$walletaddmy', '$output[0]', '$output1[0]', '$output1[1]', '$publickeymy', 0, 0, '$n')";
			$res = mysql_query($query);
			
			
		}
		
	   }
	   else
	   {
	   	echo "You have less coins";
	   }
   }

   else
   {
   		echo "enter valid address";
   }
   
   
 }
 
?>

<html>
<style>
.navbar {
    overflow: hidden;
    background-color: #333;
    position: fixed; /* Set the navbar to fixed position */
    top: 0; /* Position the navbar at the top of the page */
    width: 100%; /* Full width */
}

/* Links inside the navbar */
.navbar a {
    float: right;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 25%;
}
form {
    border: 40px solid #f1f1f1;
}
</style>

<body>

<!--div class="navbar">
  <a href="index.html">Home</a>
  <a href=""><?php echo htmlentities($name);?></a>
  <a href=""><?php echo htmlentities($balance);?></a>

  <a href="logout.php">logout</a> 
</div-->

<div id="contact-form">

  <form  method="post" action="send.php">
		<div align=center >
			<h1 >Send coin</h1>
		      <label for="to">
		      	<span class="required" >To*:</span>
		      	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" id="to" name="to" placeholder="Enter wallet address " required="required" tabindex="1" autofocus="autofocus" />

		      	
		      	 </label>  
			</div>
			
			<div  align=center >		          
		      <label for="amount"   >
		      	<span class="required"   >Amount*:</span> 
		      	<input type="text"   id="amount" name="amount" placeholder="Enter amount " required="required" tabindex="1" autofocus="autofocus" />
		      				     

		      </label> 
			</div>
			
<div  align=center class="wrapper">
<button name="send" type="submit" id="submit" align="center"> Send</button> 

</div>

</form>
</div>

</body>
</html>
