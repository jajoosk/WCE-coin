<?php 

ob_start();
session_start();
 
$name = $_SESSION['name'];
$balance = $_SESSION['balance'];

require_once 'dbconnect.php';
$res=mysql_query("SELECT walletadd,balance FROM BitcoinProject WHERE name !='$name'");
//$row1=mysql_fetch_array($res);
//$count = mysql_num_rows($res); 

if(isset($_POST['send']))
{
	header("Location: send.php");
}
if(isset($_POST['request']))
{
	header("Location: request.php");
}
if(isset($_POST['verify']))
{

	header("Location: verify.php");
}
if(isset($_POST['check']))
{
	
	header("Location: check.php");
}

?>

<html>
<style>
.navbar {
    overflow: hidden;
    background-color: #333;
    position: fixed; /* Set the navbar to fixed position */
    top: 0; /* Position the navbar at the top of the page */
    width: 100%; /* Full width */
}

/* Links inside the navbar */
.navbar a {
    float: right;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 24%;
}
.wrapper {
    text-align: center;
}


form {
    border: 10px solid #f1f1f1;
}

</style>
<body>
    





	<div class="navbar">
 		 <a href="index.html">Home</a>
  		<a href=""><?php echo htmlentities($name);?></a>
  		<a href=""><?php echo htmlentities($balance);?></a>

  		<a href="logout.php">logout</a>
	</div>
	</br>
	</br>
	</br>
	</br>
	<table border="2">
  <thead>
    <tr>

      <th>Wallet Address</th>

      <th>Balance</th>
    </tr>
  </thead>
  <tbody>
<?php
     
        while( $row = mysql_fetch_assoc( $res ) ){
          echo "<tr><td>{$row['walletadd']}</td><td>{$row['balance']}</td></tr>\n";
        }
	
    ?>
  </tbody>
</table>

	
	<form  name="form1" method="post">


	<button align=left name="send" type="submit" id="submit" >send</button> 

	
	    <button align=right name="request" type="submit" id="submit" >request</button> 
	    <button align=right name="verify" type="submit" id="submit" >verify</button> 
	    <button align=right name="check" type="submit" id="submit" >check</button> 
	</form>

</body>
</html>
